using System.Diagnostics;
using System.Diagnostics.Metrics;
using System.Drawing.Printing;
using System.Collections.Generic;
using System.CodeDom.Compiler;
using System.Dynamic;
using System.Text;
using System.Reflection;

namespace nemonlabdrv
{
    public partial class Form1 : Form
    {
        String instructions=
         "\n This expects an external file specified as the"
		 + "\n         first argument in the command line call, its format is:"
         + "\n the first line is the template-file-name followed by lines of"
		 + "\n		   (no '^' with in any of the text-to-print):"
         + "\n box-name^text-to-print"
         + "\n    or for text boxes only:"
         + "\n box_name^"
         + "\n multiple lines of text"
         + "\n ^"
         + "\n "
         + "\n "
         + "\n The format of the template file is x,data"
         + "\n where x and data are:"
         + "\n p printer name"
         + "\n l landscape mode (no data)"
         + "\n t,\"font name\",font_size,x-position,y-position,x-box-size,y-box-size,box-name"
         + "\n     if font_size<0 then the abs is sed and the font is bold"
         + "\n b,\"bar-code-type\",x-position,y-position,x-size,y-size,box-name"
         + "\n i, \"image-file\",x-position,y-position,x-size,y-size"
         + "\n "
         + "\n The lines p and l must preceed any others."
         + "\n all positions and x-y sizes are in units of 1/100 inch"
		 + "\n"
		 + "\n see the zint manual page 19 for the list of allowed barcode types";
        enum boxtype {
            text,   //text onlyy output
            barcode,    //barcode output
            image   //image from file
        };
        struct textlistStruct 
        {
            public boxtype boxType; //the type of box to use
            public String font_name;
            public float font_size; //for text if the value is <0 then the font becomes bold.
            public int x_position;
            public int y_position;
            public int x_box_size;
            public int y_box_size;
            public String boxname;
            public String printed_text;
        };
 


        List<textlistStruct> textlist = new List<textlistStruct>(); //variable length list of text commands.

        struct template_requests_struct
        {
            public String boxname;
            public String printed_text;
        };
        List<template_requests_struct> template_requests = new List<template_requests_struct>();    //set up a list of all the template requests

        public Form1(String printcmd)
        {
            String template_name = "some_file";
            bool continuation_line = false;
            PrintDocument pd = new PrintDocument();
            InitializeComponent();
            template_requests_struct ltmp = new template_requests_struct();
            File.Delete("debuglab.txt");   //insure old files are not used
            if (!File.Exists(printcmd))
                {
                MessageBox.Show(instructions);
                this.Close();
                }
            try
            {
                foreach (String cline in System.IO.File.ReadLines(printcmd))
                {
                    debuglog(cline);//#######################################
                    if (continuation_line)
                    {
                        if (cline.IndexOf("^") < 0)
                            ltmp.printed_text += cline+"\n";  //keep adding the lines for printing
                        else
                        {
                            continuation_line = false;  //this was the end
                            template_requests.Add(ltmp); 
                        }
                    }
                    else
                    {
                        if (cline.IndexOf("^") < 0)
                        {//this was just the file name
                            ltmp.boxname = cline;
                            ltmp.printed_text = "";
                            template_requests.Add(ltmp);
                        }
                        else
                        {//there is at least one ^ in the string
                            String[] args = cline.Split('^');
                            ltmp.boxname = args[0]; //box name or file name
                            debuglog(args.Count().ToString() +" " + args[1].Length.ToString());//##############################################################
                            if (args.Count() > 1 && args[1].Length>0)
                            {
                                ltmp.printed_text = args[1];
                                template_requests.Add(ltmp);
                            }
                            else
                            {//this is the start of a multiple line text
                                ltmp.printed_text = "";  //start with an empty string
                                continuation_line = true;
                            }
                        }
                    }
                }
            }
            catch { MessageBox.Show(" can not open " + printcmd);this.Close(); }
            debuglog(template_requests.Count.ToString());//#########################################################
            debuglog(debugtemplate_request());//#######################################################
            pd.DefaultPageSettings.Landscape = false;   //default to portrate
            template_name = template_requests[0].boxname;   //save the file name
            try
            {
                foreach (string line in System.IO.File.ReadLines(template_name))
                {
                    System.Console.WriteLine(line);
                    if (line.Length > 0)
                    {
                        switch (line.Substring(0, 1))
                        {
                            case "p":
                                pd.PrinterSettings.PrinterName = line.Substring(2, line.Length - 2);   //get printer name
                                break;
                            case "l":
                                pd.DefaultPageSettings.Landscape = true;
                                break;
                            case "T":
                            case "t":
                                {//text template
                                    textlistStruct tmp = new textlistStruct();
                                    String[] args = line.Split(',');
                                    tmp.boxType = boxtype.text;
                                    tmp.font_name = args[1];
                                    if (!float.TryParse(args[2], out tmp.font_size)) MessageBox.Show(" Could not parse " + line);
                                    if (!int.TryParse(args[3], out tmp.x_position)) MessageBox.Show(" Could not parse " + line);
                                    if (!int.TryParse(args[4], out tmp.y_position)) MessageBox.Show(" Could not parse " + line);
                                    if (!int.TryParse(args[5], out tmp.x_box_size)) MessageBox.Show(" Could not parse " + line);
                                    if (!int.TryParse(args[6], out tmp.y_box_size)) MessageBox.Show(" Could not parse " + line);
                                    if (line.Substring(0, 1) == "T")
                                    {//The trailing text was to be used as the printed text
                                        tmp.boxname="";
                                        tmp.printed_text = args[7]; //use last argument as the text
                                    }
                                    else
                                    {
                                        tmp.boxname = args[7];
                                        tmp.printed_text = "";  //null length if to be filled in.

                                        try
                                        {
                                            var item = template_requests.FindIndex(o => o.boxname == tmp.boxname);
                                            tmp.printed_text = template_requests[item].printed_text;   //get the actual printed text for this boxname
                                            debuglog("T index" +item.ToString()+" "+tmp.boxname+" "+tmp.printed_text);//####################################
                                        }
                                        catch { MessageBox.Show("can't find " + tmp.boxname); this.Close(); }
                                    }
                                    if (tmp.font_size==0.0 || tmp.x_box_size==0 || tmp.y_box_size==0)
                                            { MessageBox.Show("Invalidate zero values in " + line);this.Close(); }
                                    textlist.Add(tmp);
                                }
                                break;
                            case "b":
                                {//bat code template
                                    textlistStruct tmp = new textlistStruct();
                                    String[] args = line.Split(',');
                                    tmp.font_name = args[1];
                                    tmp.boxType = boxtype.barcode;
                                    tmp.font_size = 0;  //just to make it defined
                                    if (!int.TryParse(args[2], out tmp.x_position)) MessageBox.Show(" Could not parse " + line);
                                    if (!int.TryParse(args[3], out tmp.y_position)) MessageBox.Show(" Could not parse " + line);
                                    if (!int.TryParse(args[4], out tmp.x_box_size)) MessageBox.Show(" Could not parse " + line);
                                    if (!int.TryParse(args[5], out tmp.y_box_size)) MessageBox.Show(" Could not parse " + line);
                                    tmp.boxname = args[6];
                                    try
                                    {
                                        var item = template_requests.FindIndex(o => o.boxname == tmp.boxname);
                                        tmp.printed_text = template_requests[item].printed_text;   //get the actual printed text for this boxname
                                        debuglog(" index" + item.ToString() + " " + tmp.boxname + " " + tmp.printed_text);//####################################
                                    }
                                    catch { MessageBox.Show("can't find " + tmp.boxname); this.Close(); }
                                    debuglog("B font name "+tmp.font_name);//#####################################################
                                    textlist.Add(tmp);
                                }
                                break;
                            case "i":
                                {//image template
                                    textlistStruct tmp = new textlistStruct();
                                    String[] args = line.Split(',');
                                    tmp.font_name = args[1];    //image file 
                                    tmp.boxType = boxtype.image;
                                    tmp.font_size = 0;  //to make the value defined
                                    if (!int.TryParse(args[2], out tmp.x_position)) MessageBox.Show(" Could not parse " + line);
                                    if (!int.TryParse(args[3], out tmp.y_position)) MessageBox.Show(" Could not parse " + line);
                                    if (!int.TryParse(args[4], out tmp.x_box_size)) MessageBox.Show(" Could not parse " + line);
                                    if (!int.TryParse(args[5], out tmp.y_box_size)) MessageBox.Show(" Could not parse " + line);
                                    tmp.boxname = "";
                                    tmp.printed_text = "";
                                    debuglog("B font name " + tmp.font_name);//#####################################################
                                    textlist.Add(tmp);
                                }
                                break;
                        }
                    }
                }
            }
            catch
            { 
                MessageBox.Show("can't open template file");
            }
            //pd.PrinterSettings.PrinterName = "Brother QL-800";
            //pd.DefaultPageSettings.Landscape = true;
            //pd.DefaultPageSettings.PaperSize = new PaperSize("MyPaper", 47, 200);//no effect
            debuglog(debugtextlist());//##################################################
            pd.PrintPage += new PrintPageEventHandler(pd_printpage);
            pd.Print();
            //Application.Exit();
            this.Close();
        }


        public void pd_printpage(object sender, PrintPageEventArgs ev)
        {//event handler for printing
            //Get the Graphics object
            if (ev.Graphics != null)
            {
                debuglog("start print");//#######################################
                Graphics g = ev.Graphics;
                int commandno = 0;
                foreach (textlistStruct tmp in textlist)
                {
                    commandno++;
                    debuglog("P " + tmp.boxname + " font "+tmp.font_name+" size "+tmp.font_size.ToString()+" text " + tmp.printed_text);//####################################
                    switch (tmp.boxType)
                    {
                        case boxtype.text:
                            {//text output
                                FontStyle fs;
                                float font_size;
                                debuglog(tmp.boxname);//###############################################
                                if (tmp.font_size > 0)
                                {
                                    fs = FontStyle.Regular;
                                    font_size = tmp.font_size;
                                }
                                else
                                {
                                    fs = FontStyle.Bold;
                                    font_size = -tmp.font_size;
                                }

                                Font font = new Font(tmp.font_name, font_size, fs);
                                //Create a solid brush with black color  
                                SolidBrush brush = new SolidBrush(Color.Black);

                                //Draw SN;  
                                StringFormat drawFormat = new StringFormat();
                                drawFormat.FormatFlags = StringFormatFlags.DirectionVertical;

                                g.DrawString(tmp.printed_text, font, brush, new Rectangle(
                                    tmp.x_position, tmp.y_position, tmp.x_box_size, tmp.y_box_size)/*, drawFormat*/);
                            }
                            break;
                        case boxtype.barcode:
                            {//barcode
                                int ic;
                                debuglog(tmp.boxname);//###############################################
                                String graname = "recsn"+ commandno.ToString()+".png";
                                if(File.Exists(graname))
                                    File.Delete(graname);   //insure old files are not used
                                String parm = "-o "+ graname+" -d \"" + tmp.printed_text + "\" -notext --scale=4 -b " + tmp.font_name;//commands to zint
                                System.Diagnostics.Process.Start("zint.exe", parm);
                                for (ic = 0; !File.Exists(graname) && ic < 10; ic++)
                                {
                                    Thread.Sleep(500);  //the output file of Zint seems to be delayed
                                }
                                if (ic >= 10)
                                {
                                    MessageBox.Show("can not generate label for " + parm);
                                    this.Close();
                                }
                                System.Drawing.Image img = System.Drawing.Image.FromFile(graname);
                                System.Drawing.Image imgsc = new Bitmap(img, new Size(tmp.x_box_size, tmp.y_box_size));
                                Point loc = new Point(tmp.x_position, tmp.y_position);
                                ev.Graphics.DrawImage(imgsc, loc);
                            }
                            break;
                        case boxtype.image:
                            {
                                int ic;
                                debuglog(tmp.boxname);//###############################################
                                System.Drawing.Image img = System.Drawing.Image.FromFile(tmp.font_name);
                                System.Drawing.Image imgsc = new Bitmap(img, new Size(tmp.x_box_size, tmp.y_box_size));
                                Point loc = new Point(tmp.x_position, tmp.y_position);
                                ev.Graphics.DrawImage(imgsc, loc);
                            }
                            break;
                    }
                }
            }
        }

        public String debugtemplate_request()
        {
            String str = "";
            foreach (template_requests_struct dtmp in template_requests)
            {
                str += "\n      ";
                str += dtmp.boxname + " ";
                str += dtmp.printed_text;
            }
            return (str);
        }

        public String debugtextlist()
        {
            String str = "";
            foreach (textlistStruct dtmp in textlist)
            {
                str += "\n      ";
                str += dtmp.font_name + " ";
                str += dtmp.font_size.ToString() + " ";
                str += dtmp.x_position.ToString() + " ";
                str += dtmp.y_position.ToString() + " ";
                str += dtmp.x_box_size.ToString() + " ";
                str += dtmp.y_box_size.ToString() + " ";
                str += dtmp.boxname + " ";
                str += dtmp.printed_text;

            }
            return (str);
        }

 

        public void debuglog(String str)
        {
            StackFrame callStack = new StackFrame(1, true);
            using (StreamWriter sw = File.AppendText("debuglab.txt"))
            {
                sw.WriteLine(callStack.GetFileLineNumber()+" "+str);
            }
        }
    }
}