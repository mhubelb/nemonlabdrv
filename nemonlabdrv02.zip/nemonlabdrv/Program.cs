namespace nemonlabdrv
{
    internal static class Program
    {
        /// <summary>
        ///  The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main(String[] args)
        {
            // To customize application configuration such as set high DPI settings or default font,
            // see https://aka.ms/applicationconfiguration.
            ApplicationConfiguration.Initialize();
            String cmdfile = "printbar.cmd";
            if (args.Length > 0)
                cmdfile = args[0];  //use passed in value
            Application.Run(new Form1(cmdfile));
        }
    }
}